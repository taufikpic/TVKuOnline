# TVKuOnline

Aplikasi TV Online versi tes.

## Build APK dengan GitHub Actions
Setelah semua file di-upload ke branch `main`:
1. Buka tab **Actions**.
2. Pilih **Build APK**.
3. Jika build belum berjalan, tekan **Run workflow**.
4. Tunggu sampai status hijau.
5. Buka hasil run.
6. Di bagian **Artifacts**, download `TVKuOnline-debug`.
7. Ekstrak ZIP artifact lalu install `app-debug.apk`.

Gunakan hanya stream yang legal/berizin.
