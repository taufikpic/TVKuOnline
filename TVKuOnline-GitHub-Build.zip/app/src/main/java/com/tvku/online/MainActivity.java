package com.tvku.online;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private final ArrayList<Channel> allChannels = new ArrayList<>();
    private final ArrayList<Channel> filteredChannels = new ArrayList<>();
    private ArrayAdapter<Channel> adapter;
    private TextView countText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        EditText search = findViewById(R.id.search);
        ListView list = findViewById(R.id.channelList);
        countText = findViewById(R.id.channelCount);

        String demo = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";
        allChannels.add(new Channel("Demo TV", "Hiburan", demo));
        allChannels.add(new Channel("Demo News", "Berita", demo));
        allChannels.add(new Channel("Demo Sports", "Olahraga", demo));

        filteredChannels.addAll(allChannels);

        adapter = new ArrayAdapter<Channel>(
                this,
                android.R.layout.simple_list_item_1,
                filteredChannels
        ) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView tv = v.findViewById(android.R.id.text1);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(16);
                tv.setPadding(24, 28, 24, 28);
                v.setBackgroundColor(Color.rgb(17, 24, 39));
                return v;
            }
        };

        list.setAdapter(adapter);
        list.setDivider(new ColorDrawable(Color.rgb(9, 13, 22)));
        list.setDividerHeight(8);

        updateCount();

        list.setOnItemClickListener((parent, view, position, id) -> {
            Channel channel = filteredChannels.get(position);
            Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
            intent.putExtra("name", channel.name);
            intent.putExtra("url", channel.url);
            startActivity(intent);
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }
        });
    }

    private void filter(String query) {
        String q = query.toLowerCase(Locale.US).trim();
        filteredChannels.clear();

        for (Channel channel : allChannels) {
            if (q.isEmpty()
                    || channel.name.toLowerCase(Locale.US).contains(q)
                    || channel.category.toLowerCase(Locale.US).contains(q)) {
                filteredChannels.add(channel);
            }
        }

        adapter.notifyDataSetChanged();
        updateCount();
    }

    private void updateCount() {
        countText.setText(filteredChannels.size() + " channel");
    }
}
