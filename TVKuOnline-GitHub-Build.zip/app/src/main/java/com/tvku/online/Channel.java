package com.tvku.online;

public class Channel {
    public final String name;
    public final String category;
    public final String url;

    public Channel(String name, String category, String url) {
        this.name = name;
        this.category = category;
        this.url = url;
    }

    @Override
    public String toString() {
        return name + "  •  " + category;
    }
}
