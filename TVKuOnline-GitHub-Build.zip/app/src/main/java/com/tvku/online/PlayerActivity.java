package com.tvku.online;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class PlayerActivity extends Activity {

    private VideoView videoView;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.player);

        videoView = findViewById(R.id.videoView);
        statusText = findViewById(R.id.statusText);

        String name = getIntent().getStringExtra("name");
        String url = getIntent().getStringExtra("url");

        TextView title = findViewById(R.id.playerTitle);
        title.setText(name == null ? "TV Online" : name);

        if (url == null || url.isEmpty()) {
            statusText.setText("URL stream kosong");
            return;
        }

        MediaController controller = new MediaController(this);
        controller.setAnchorView(videoView);
        videoView.setMediaController(controller);

        statusText.setText("Memuat siaran...");
        statusText.setVisibility(View.VISIBLE);

        videoView.setVideoURI(Uri.parse(url));

        videoView.setOnPreparedListener(mp -> {
            statusText.setVisibility(View.GONE);
            videoView.start();
        });

        videoView.setOnErrorListener((mp, what, extra) -> {
            statusText.setText("Siaran gagal diputar.\nCoba stream HLS lain.");
            statusText.setVisibility(View.VISIBLE);
            return true;
        });
    }

    @Override
    protected void onDestroy() {
        if (videoView != null) {
            videoView.stopPlayback();
        }
        super.onDestroy();
    }
}
